
How to run the project:

1. Open create_db.sql in MySQL Workbench and run it.
2. Open this folder in VS Code.
3. Compile:
   javac -cp ".;lib/mysql-connector-j-9.3.0.jar" Main.java

4. Run:
   java -cp ".;lib/mysql-connector-j-9.3.0.jar" Main

Presentation Tip:
This Java GUI counter app uses MySQL to store the counter value persistently.
