
CREATE DATABASE counter_app;

USE counter_app;

CREATE TABLE counter_value (
    id INT PRIMARY KEY,
    value INT NOT NULL
);

INSERT INTO counter_value (id, value) VALUES (1, 0);
