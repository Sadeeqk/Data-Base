// Style manager placeholder
